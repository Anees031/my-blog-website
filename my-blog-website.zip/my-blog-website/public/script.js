async function addPost() {
    const postTitle = document.getElementById("postTitle").value.trim();
    const postContent = document.getElementById("postContent").value.trim();
    const postAuthor = document.getElementById("postAuthor").value.trim();
    
    if (postTitle && postContent && postAuthor) {
        const response = await fetch('/api/posts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title: postTitle, content: postContent, author: postAuthor })
        });

        if (response.ok) {
            const { message, post } = await response.json();
            alert(message);
            displayPost(post);
            clearForm();
        } else {
            alert('Failed to add post');
        }
    } else {
        alert('Please enter title, content, and author.');
    }
}

async function displayPosts() {
    try {
        const response = await fetch('/api/posts');
        if (!response.ok) {
            throw new Error('Failed to retrieve posts');
        }
        const posts = await response.json();
        const postList = document.getElementById("postList");
        postList.innerHTML = "";

        posts.forEach(post => {
            displayPost(post);
        });
    } catch (error) {
        console.error('Error retrieving posts:', error.message);
        alert('Failed to retrieve posts. Please try again.');
    }
}

function displayPost(post) {
    const postList = document.getElementById("postList");

    const postContainer = document.createElement("div");
    postContainer.classList.add("post");

    const title = document.createElement("h2");
    title.textContent = post.title;

    const author = document.createElement("h4");
    author.textContent = `Author: ${post.author}`;

    const content = document.createElement("p");
    content.textContent = post.content;

    postContainer.appendChild(title);
    postContainer.appendChild(author);
    postContainer.appendChild(content);
    postList.appendChild(postContainer);
}

function clearForm() {
    document.getElementById("postTitle").value = "";
    document.getElementById("postContent").value = "";
    document.getElementById("postAuthor").value = "";
}

document.addEventListener('DOMContentLoaded', () => {
    displayPosts();
});
